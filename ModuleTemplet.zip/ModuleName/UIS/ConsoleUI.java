public class ConsoleUI implements ItfUI {

    @Override
    public void onCreate() {

    }

    @Override
    public void onShowUI() {
        while(true){
            //显示界面
            System.out.println("===========欢迎来到xxx===========");
            System.out.println("1.xxx。");
            System.out.println("2.xxx。");
            System.out.println("q.退出。");
            //读取输入
            Scanner scanner = new Scanner(System.in);
            try {
                switch (scanner.nextInt()){
                    case 1:
                        break;
                    case 2:
                        break;
                    default:
                        logInfo("输入错误！请重新输入！",null);
                }
            }catch (InputMismatchException e){
                if(scanner.next().equals("q"))
                    return;
                else
                    logInfo("输入错误！请重新输入！",e);
            }
            catch (Exception e) {
                logInfo("输入错误！请重新输入！",e);
            }
        }
    }

    @Override
    public void onExit() {

    }

}