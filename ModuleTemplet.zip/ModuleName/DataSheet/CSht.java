
//常量表
public class CSht {
    //模块运行模式，调试\发布...
    public static RUN_MODE_TYPE RUN_MODE= RUN_MODE_TYPE.DEBUG;
    public static String NAME="模块名";
    public static String VERSION="模块版本号";//示例0.1

    public enum RUN_MODE_TYPE{
        DEBUG,RELEASE
    }
}