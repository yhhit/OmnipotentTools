
//常量表
public class CSht {
    //模块运行模式，调试\发布...
    public static xyz.yhhit.OmnipotentTools.DataSheet.CSht.RUN_MODE_TYPE RUN_MODE= xyz.yhhit.OmnipotentTools.DataSheet.CSht.RUN_MODE;
    public static String NAME="模块名";
    public static String VERSION="模块版本号";//示例0.1
}